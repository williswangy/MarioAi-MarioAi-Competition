package ch.idsia.agents.controllers.BehaviorTree;

import ch.idsia.benchmark.mario.engine.sprites.Mario;

/**
 * Yuan Wang and JiuChuan Wang
 * class isJump extends the Task
 * If mario's status is SUCCESS => mario is able to jump and check whether it is not on the ground
 */
public class isJump extends Task
{

    public boolean run()
    {

        marioStatus = MarioStatus.SUCCESS;
        agent.action[Mario.KEY_JUMP] = agent.isMarioAbleToJump || !agent.isMarioOnGround;
        return true;
    }
}
