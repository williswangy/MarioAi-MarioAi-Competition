package ch.idsia.agents.controllers.BehaviorTree;

import ch.idsia.benchmark.mario.engine.sprites.Mario;

/**
 * Yuan Wang and JiuChuan Wang
 * class isShoot extends the Task
 * If mario's status is SUCCESS => mario is able to shoot
 */

public class isShoot extends Task {

    public boolean run()
    {
        marioStatus = MarioStatus.SUCCESS;
        agent.action[Mario.KEY_SPEED] = agent.isMarioAbleToShoot;
        return true;
    }
}
