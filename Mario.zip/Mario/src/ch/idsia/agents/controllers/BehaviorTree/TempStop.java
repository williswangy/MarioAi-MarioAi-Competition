package ch.idsia.agents.controllers.BehaviorTree;

import ch.idsia.benchmark.mario.engine.sprites.Mario;

/**
 * Yuan Wang and JiuChuan Wang
 * class TempStop extends the Task
 * This class is to make the agent behaving like a human which has the thinking and hesitating.

 */
public class TempStop extends Task
{

    public boolean run()
    {
        if (agent.steps < 5)
            return true;
        else if (agent.steps < 15 && !agent.enemyNear() && !agent.enemyBehind() && !agent.wallRight())
        {
            agent.action[Mario.KEY_RIGHT] = false;
            agent.steps += 1;
            return false;
        }
        else {
            agent.steps = 0;
            return true;
        }
    }
}
