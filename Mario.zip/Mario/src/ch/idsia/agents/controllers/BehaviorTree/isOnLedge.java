package ch.idsia.agents.controllers.BehaviorTree;

/**
 * Yuan Wang and JiuChuan Wang
 * class isOnLedge extends the Task
 * If agent's onLedge is true || mario's status is SUCCESS => it is on the ledge
 */
public class isOnLedge extends Task
{

    public boolean run()
    {
        if (agent.onLedge())
        {

            marioStatus = MarioStatus.SUCCESS;
            return true;
        }
        marioStatus = MarioStatus.FAILURE;
        return false;
    }
}
