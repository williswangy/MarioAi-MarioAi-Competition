package ch.idsia.agents.controllers.BehaviorTree;

import ch.idsia.benchmark.mario.engine.sprites.Mario;

/**
 * Yuan Wang and JiuChuan Wang
 * class isLeft extends the Task
 * If mario's status is SUCCESS => mario is move left
 * else return the FAILURE
 */
public class isLeft extends Task
{

    public boolean run()
    {
        if (!agent.action[Mario.KEY_LEFT])
        {
            agent.action[Mario.KEY_LEFT] = true;
            marioStatus = MarioStatus.SUCCESS;
            return true;
        }

        marioStatus = MarioStatus.FAILURE;
        return false;
    }
}
