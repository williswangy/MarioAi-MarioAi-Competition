package ch.idsia.agents.controllers.BehaviorTree;

/**
 * Yuan Wang and JiuChuan Wang
 * class isWallRightRight extends the Task
 * If agent's wallRight is true => there is wall on the right
 */
public class isWallRight extends Task
{

    public boolean run()
    {
        if (agent.wallRight())
        {
            return true;
        }
        return false;
    }
}