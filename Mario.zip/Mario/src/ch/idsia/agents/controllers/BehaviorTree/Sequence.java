package ch.idsia.agents.controllers.BehaviorTree;

import java.util.List;
import java.util.ListIterator;

/**
 * Yuan Wang and JiuChuan Wang
 * class Sequence extends the Task
 *
 */

public class Sequence extends Composite {

    protected ListIterator<Task> current;

    public Sequence(List<Task> _children){
            super(_children);

        current = children.listIterator();
    }

    public boolean run(){

        if (!current.hasNext())
        {     // reached end of list
            marioStatus = MarioStatus.SUCCESS;
            return true;
        }
        if (current.next().run())
        {
            marioStatus = MarioStatus.RUNNING;
            return false;
        }
        else// child failed
        {
            marioStatus = MarioStatus.FAILURE;
            return false;
        }
    }

    public void reset()
    {
        current = children.listIterator();  //reset the list

        while (current.hasNext())//not empty
        {
            Task child = current.next();
            //If the child is a composite
            if (child instanceof Composite)
                ((Composite) child).reset();
        }

        current = children.listIterator();
    }
}
