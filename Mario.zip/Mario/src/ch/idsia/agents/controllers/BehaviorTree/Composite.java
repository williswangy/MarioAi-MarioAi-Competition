package ch.idsia.agents.controllers.BehaviorTree;

import java.util.List;

/**
 * Yuan Wang and JiuChuan Wang
 * class Composite extends the Task
 * Composite Nodes define the root of a branch and the base rules for how that branch is executed
 */
public abstract class Composite extends Task
{

    List<Task> children;

    public Composite(List<Task> _children)
    {
        children = _children;
    }

    //reset the current pointer to first child
    public abstract void reset();
}
