package ch.idsia.agents.controllers.BehaviorTree;

import ch.idsia.benchmark.mario.engine.sprites.Mario;

/**
 * Yuan Wang and JiuChuan Wang
 * class isRight extends the Task
 * If mario's status is SUCCESS => mario continue moving right
 */
public class isRight extends Task
{

    public boolean run()
    {

        if (!agent.wallRight())
        {
            marioStatus = MarioStatus.SUCCESS;
            agent.action[Mario.KEY_RIGHT] = true;
            agent.steps += 1;
            return true;
        }

        return false;
    }
}
