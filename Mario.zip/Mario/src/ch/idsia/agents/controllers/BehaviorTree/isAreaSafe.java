package ch.idsia.agents.controllers.BehaviorTree;

import ch.idsia.benchmark.mario.engine.sprites.Mario;

/**
 * Yuan Wang and JiuChuan Wang
 * class isAreaSafe extends the Task
 * check whether the area is safe
 */


public class isAreaSafe extends Task
{

    public boolean run()
    {
        if (!agent.areaSafe() && !agent.pathBlocked())
        {

            agent.action[Mario.KEY_RIGHT] = false;
        }
        else { }
        return (agent.areaSafe());
    }
}
