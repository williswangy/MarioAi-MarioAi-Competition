package ch.idsia.agents.controllers.BehaviorTree;

/**
 * Yuan Wang and JiuChuan Wang
 * class isEnemyNear extends the Task
 * If agent's enemyNear is true => Enemy is nearby
 */
public class isEnemyNear extends Task
{
    public boolean run()
    {
        if (agent.enemyNear())
        {

            return true;
        }
        return false;
    }
}
