package ch.idsia.agents.controllers.BehaviorTree;
/**
 * Yuan Wang and JiuChuan Wang
 * class isBrickAbove extends the Task
 * If agent's brickAbove is true => it has a brick above
 */

public class isBrickAbove extends Task
{

    public boolean run()
    {
        if(agent.brickAbove())
            return true;
        return false;
    }
}
