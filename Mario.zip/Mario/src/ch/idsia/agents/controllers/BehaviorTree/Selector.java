package ch.idsia.agents.controllers.BehaviorTree;

import java.util.List;
import java.util.ListIterator;

import static ch.idsia.agents.controllers.BehaviorTree.Task.MarioStatus.RUNNING;

/**
 * Yuan Wang and JiuChuan Wang
 * class Selector extends the Task
 * Select the mario status
 *
 */

public class Selector extends Composite
{

    ListIterator<Task> current;

    public Selector(List<Task> _children)
    {
        super(_children);

        current = children.listIterator();
    }

    public boolean run()
    {

        if (current.hasNext())
        {
            Task child = current.next();
            child.run();
            if (child.marioStatus == MarioStatus.SUCCESS)
            {
                marioStatus = MarioStatus.SUCCESS;
                return true;
            } else if (child.marioStatus == MarioStatus.FAILURE)
            {
                marioStatus = MarioStatus.RUNNING;
                return false;
            } else if (child.marioStatus == RUNNING)
            {
                marioStatus = MarioStatus.RUNNING;
                current.previous();
                return false;
            }
        }

        marioStatus = MarioStatus.FAILURE;
        return false;

    }


    public void reset()
    {
        current = children.listIterator();

        while (current.hasNext())
        {
            Task child = current.next();
            if (child instanceof Composite)
                ((Composite) child).reset();
        }

        current = children.listIterator();
    }
}
