package ch.idsia.agents.controllers.BehaviorTree;

/**
 * Yuan Wang and JiuChuan Wang
 * class isEnemyBehind extends the Task
 * If agent's enemyBehind is true and mario's status is SUCCESS => enemy is behind
 */
public class isEnemyBehind extends Task
{

    public boolean run()
    {
        if (agent.enemyBehind())
        {

            marioStatus = MarioStatus.SUCCESS;
            return true;
        }

        marioStatus = MarioStatus.FAILURE;
        return false;
    }
}
