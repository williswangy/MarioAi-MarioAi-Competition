package ch.idsia.agents.controllers.BehaviorTree;

import ch.idsia.agents.controllers.BehaviorTreeAgent;

/**
 * Yuan Wang and JiuChuan Wang
 * class isShoot extends the Task
 * Abstract class Task which contains the three different Status RUNNING, SUCCESS, FAILURE
 */
public abstract class Task
{

    public enum MarioStatus
    {
        RUNNING, SUCCESS, FAILURE;

        public String getString()
        {
            switch (this)
            {
                case RUNNING:
                    return "RUNNING";
                case SUCCESS:
                    return "SUCCESS";
                default:
                    return "FAILURE";
            }
        }
    }

    public BehaviorTreeAgent agent;
    public abstract boolean run();

    public MarioStatus marioStatus;


}
