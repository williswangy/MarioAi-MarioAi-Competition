package ch.idsia.benchmark.tasks;

import ch.idsia.agents.controllers.BehaviorTree.*;
import ch.idsia.benchmark.mario.engine.sprites.Mario;

/**
 * Yuan Wang and JiuChuan Wang
 * class AreaNotSafe extends the Task
 * Define the new Task.
 */
public class AreaNotSafe extends ch.idsia.agents.controllers.BehaviorTree.Task
{

    public boolean run()
    {

        if (!agent.areaSafe() && !agent.pathBlocked())
        {

            agent.action[Mario.KEY_RIGHT] = false;
        }
        else { }
        return (!agent.areaSafe());
    }
}
