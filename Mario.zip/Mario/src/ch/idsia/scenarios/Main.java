/*
 * Copyright (c) 2009-2010, Sergey Karakovskiy and Julian Togelius
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Mario AI nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package ch.idsia.scenarios;

import ch.idsia.agents.controllers.BehaviorTreeAgent;
import ch.idsia.agents.controllers.BehaviorTree.*;
import ch.idsia.agents.controllers.BehaviorTree.isWallRight;
import ch.idsia.benchmark.tasks.AreaNotSafe;
import ch.idsia.benchmark.tasks.BasicTask;
import ch.idsia.tools.MarioAIOptions;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: Sergey Karakovskiy, sergey at idsia dot ch Date: Mar 17, 2010 Time: 8:28:00 AM
 * Package: ch.idsia.scenarios
 */
public final class Main
{
public static void main(String[] args)
{
        //final String argsString = "-vis off";
        final MarioAIOptions marioAIOptions = new MarioAIOptions(args);
        //final Environment environment = new MarioEnvironment();
//        final Agent agent = new ForwardAgent();


    /**
     * The following methods are for creating new Tasks from our own BehaviorTree
     */

    //[ -----Behavior Leaves----- ]
    Task shoot = new isShoot();
    Task enemyNear = new isEnemyNear();
    Task moveRight = new isRight();
    Task areaSafe = new isAreaSafe();
    Task wallRight = new isWallRight();
    Task jump = new isJump();
    Task brickAbove = new isBrickAbove();
    Task tempStop = new TempStop();
    Task onLedge = new isOnLedge();
    Task areaNotSafe = new AreaNotSafe();
    Task enemyBehind = new isEnemyBehind();
    Task turnLeft = new isLeft();

    /**
     * Children part which will create each function
     */

    // isShoot nearby enemies
    List<Task> childrenSequence1 = new ArrayList<>();
    childrenSequence1.add(enemyNear);
    childrenSequence1.add(jump);
    childrenSequence1.add(shoot);


    // isJump over walls
    List<Task> childrenSequence2 = new ArrayList<>();
    //childrenSequence2.add(shoot); ==> will crash in somewhere
    childrenSequence2.add(wallRight);
    childrenSequence2.add(jump);
    childrenSequence2.add(shoot);

    // Move right, stop intermittently
    List<Task> childrenSequence3 = new ArrayList<>();
    childrenSequence3.add(shoot);
    childrenSequence3.add(moveRight);
    childrenSequence3.add(tempStop);
    //childrenSequence3.add(shoot);==> will crash in somewhere

    // isJump if brick above
    List<Task> childrenSequence4 = new ArrayList<>();
    childrenSequence4.add(brickAbove);
    childrenSequence4.add(jump);

    // isJump if on ledge
    List<Task> childrenSequence5 = new ArrayList<>();
    childrenSequence5.add(shoot);
    childrenSequence5.add(onLedge);
    childrenSequence5.add(jump);

    // Clear area
    List<Task> childrenSequence6 = new ArrayList<>();
    childrenSequence6.add(areaNotSafe);
    childrenSequence6.add(shoot);


    // Cliff right and enemy
    List<Task> childrenSequence7 = new ArrayList<>();
    childrenSequence7.add(areaNotSafe);
    childrenSequence7.add(wallRight);
    childrenSequence7.add(turnLeft);
    childrenSequence7.add(moveRight);

    //[ -----Composite Nodes----- ]
    Composite sequence1 = new Sequence(childrenSequence1);    // isShoot nearby enemies
    Composite sequence2 = new Sequence(childrenSequence2);    // isJump over walls
    Composite sequence3 = new Sequence(childrenSequence3);    // Move right
    Composite sequence4 = new Sequence(childrenSequence4);    // isJump for bricks
    Composite sequence5 = new Sequence(childrenSequence5);    // isJump off ledge
    Composite sequence6 = new Sequence(childrenSequence6);    // Clear unsafe area
    Composite sequence7 = new Sequence(childrenSequence7);

    List<Task> childrenSelector = new ArrayList<>();
    childrenSelector.add(sequence1);
    childrenSelector.add(sequence5);
    childrenSelector.add(sequence3);
    childrenSelector.add(sequence2);
    Composite sel = new Selector(childrenSelector);
    BehaviorTreeAgent agent = new BehaviorTreeAgent(sel);

    enemyNear.agent = agent;
    shoot.agent = agent;
    areaSafe.agent = agent;
    moveRight.agent = agent;
    wallRight.agent = agent;
    jump.agent = agent;
    brickAbove.agent = agent;
    tempStop.agent = agent;
    onLedge.agent = agent;
    areaNotSafe.agent = agent;
    enemyBehind.agent = agent;
    turnLeft.agent = agent;
    sequence1.agent = agent;
    sequence2.agent = agent;
    sequence3.agent = agent;
    sequence4.agent = agent;
    sequence5.agent = agent;
    sequence6.agent = agent;
    sel.agent = agent;


    marioAIOptions.setAgent(agent);
//        final Agent agent = marioAIOptions.getAgent();
//        final Agent a = AgentsPool.loadAgent("ch.idsia.controllers.agents.controllers.ForwardJumpingAgent");
    final BasicTask basicTask = new BasicTask(marioAIOptions);

    basicTask.setOptionsAndReset(marioAIOptions);
//    basicTask.runSingleEpisode(1);
    basicTask.doEpisodes(1,true,1);
//    System.out.println(basicTask.getEnvironment().getEvaluationInfoAsString());
//            } while (basicTask.getEnvironment().getEvaluationInfo().marioStatus != Environment.MARIO_STATUS_WIN);
//        }
//
    System.exit(0);
}

}


